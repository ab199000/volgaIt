package org.example.account;

import jakarta.persistence.*;

@Entity
@Table
public class Account {
    @Id
    @SequenceGenerator(
            name = "username_sequence",
            sequenceName = "username_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "username_sequence"
    )

    private Long id;
    private String username;
    private String password;
    private Boolean isAdmin = false;
    private Double balance = 0.0;

    public Account() {
    }

    public Account(Long id, String username, String password, String role, Boolean isAdmin, Double balance) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.isAdmin = isAdmin;
        this.balance = balance;
    }

    public Account(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getAdmin() {
        return isAdmin;
    }

    public void setAdmin(Boolean admin) {
        isAdmin = admin;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Account{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", isAdmin=" + isAdmin +
                ", balance=" + balance +
                '}';
    }
}

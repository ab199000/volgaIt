package org.example.account;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
//@RequestMapping(path = "api/Account")
public class AccountController {

    private final AccountService accountService;

    @Autowired
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

//    @GetMapping(path = "api/Account/Me")
    @PostMapping(path = "api/Account/SignUp")
    public void registerNewAccount(@RequestBody Account account){
        accountService.addNewAccount(account);
    }
//    @PostMapping(path = "api/Account/SignIn")

//    @PostMapping(path = "api/Account/SignOut")
//    @PostMapping(path = "api/Account/Update")


}

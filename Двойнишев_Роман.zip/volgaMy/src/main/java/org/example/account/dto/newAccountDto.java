package org.example.account.dto;

public class newAccountDto {

    private String username;
    private String password;
    private Boolean isAdmin = false;
    private Double balance = 0.0;
}

package org.example.adminTranstor;

public class AdminTranstorService {
}

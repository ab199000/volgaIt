package org.example.adminTranstor;

public class AdminTranstorController {
}

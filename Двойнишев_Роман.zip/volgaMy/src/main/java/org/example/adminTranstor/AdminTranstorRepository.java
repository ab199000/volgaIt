package org.example.adminTranstor;

public interface AdminTranstorRepository {
}
